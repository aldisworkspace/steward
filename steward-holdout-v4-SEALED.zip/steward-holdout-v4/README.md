# Steward hold-out v4 (SEALED)

**SYNTHETIC — generated for testing.** Every organization, agency, foundation, person, vendor, address and amount here is fictional.

**SEALED: do not open while changing detection logic; score once.**

Org: Kettle Basin Conservation Corps (young-adult conservation corps doing watershed restoration, plus a school field-science program).
Period: April-July 2026. Funders: Westmere Office of Environmental Workforce Development (fictional state office; cost-reimbursement contract OEWD-27-0058,
invoiced monthly) and the Halvorsen-Pike Foundation (fictional private foundation; grant HPF-2026-077, paid in advance, no invoices).

| File | What |
|---|---|
| `contract_OEWD-27-0058_westmere_environmental_workforce.pdf` | State contract, cost-reimbursement, monthly invoices |
| `grant_HPF-2026-077_halvorsen_pike_foundation.pdf` | Foundation grant paid in advance, interim and final reports |
| `gl_transaction_detail_by_account.csv` | QuickBooks Online "Transaction Detail by Account" export (155 transaction lines, grouped by account with totals) |
| `bank_statement.csv` | Checking account activity (70 lines) |
| `staff_allocation.csv` | Payroll allocation schedule on file |
| `precedents.json` | Funder rulings on file |
| `receipts/` | 29 receipts, invoices and statements (PDF, plus 4 PNG photos) |
| `expected_v4.json` | Answer key (issues, clean lines, expected invoice package totals). Scorer-only. |
| `_generator/generate_holdout_v4.py` | The generator (inside the sealed zip only) |

Regenerate (deterministic, seed 41207):

```
uv run --with reportlab --with faker --with pillow python steward-holdout-v4/_generator/generate_holdout_v4.py --out <dir> --zip <dir>/steward-holdout-v4-SEALED.zip --keep
```

Score: `npx tsx scripts/eval-v2-dev.ts --dir steward-holdout-v4`.
