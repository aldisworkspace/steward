"""
SEALED hold-out v4 for Steward. Written independently of the detection code and of earlier sets.

Fictional org (young-adult conservation corps doing watershed restoration), a fictional state-agency
contract (cost-reimbursement, monthly invoices) and a fictional private foundation grant paid in
advance (interim/final reports, no invoices). Every document is synthetic.

Run:  uv run --with reportlab --with faker --with pillow python generate_holdout_v4.py [--out DIR] [--zip PATH] [--keep]
Out:  DIR/steward-holdout-v4/ (built), then PATH (default ./steward-holdout-v4-SEALED.zip) containing the
      folder plus _generator/generate_holdout_v4.py. The unzipped folder is removed unless --keep.
"""
import csv
import hashlib
import io
import json
import os
import random
import re
import shutil
import sys
import zipfile
from datetime import date, timedelta

from faker import Faker
from PIL import Image, ImageDraw, ImageFont
from reportlab import rl_config
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

rl_config.invariant = 1  # deterministic PDF bytes

SEED = 41207
rng = random.Random(SEED)
fake = Faker("en_US")
Faker.seed(SEED)


def _arg(name, default):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default


BASE = os.path.abspath(_arg("--out", os.getcwd()))
OUT = os.path.join(BASE, "steward-holdout-v4")
ZIP = os.path.abspath(_arg("--zip", os.path.join(os.getcwd(), "steward-holdout-v4-SEALED.zip")))
LABEL = "SYNTHETIC — generated for testing"

ORG = "Kettle Basin Conservation Corps"
ORG_ADDR = "2290 Millrace Road, Harrow Ferry, WM 70318"
STATE = "State of Westmere"
AGENCY = "Westmere Office of Environmental Workforce Development"
OEWD = "OEWD-27-0058"
HPF = "HPF-2026-077"
FOUND = "Halvorsen-Pike Foundation"
TAX_BP = 685  # 6.85% fictional Westmere sales tax
CHECKING = "1000 Fernbank Community Bank Checking"
AP = "2000 Accounts Payable (A/P)"
CARD = "Debit card ****2093"

money = lambda c: f"${c / 100:,.2f}"
amt = lambda c: f"{c / 100:.2f}"
mdy = lambda d: d.strftime("%m/%d/%Y")
D = lambda m, d: date(2026, m, d)


def rhu(x):
    return int(x + 0.5) if x >= 0 else -int(-x + 0.5)


def tax_of(cents):
    return (cents * TAX_BP + 5000) // 10000 if cents >= 0 else -((-cents * TAX_BP + 5000) // 10000)


CITIES = ["Harrow Ferry", "Bramble Point", "Oxley Mills", "North Tamsin"]


def addr():
    return f"{fake.street_address()}, {rng.choice(CITIES)}, WM {rng.randint(70300, 70399)}"


# ----------------------------------------------------------------------------- funding terms
OEWD_LINES = [
    ("C1", "Personnel - crew leaders & program staff", 17200000),
    ("C2", "Fringe benefits", 4472000),
    ("C3", "Participant support - corps member stipends & deployment meals", 9600000),
    ("C4", "Field supplies & materials", 1850000),
    ("C5", "Vehicle & field travel", 2160000),
    ("C6", "Equipment", 800000),
    ("C7", "Safety training & certifications", 600000),
    ("C8", "Indirect costs", 3100000),
]
OEWD_TOTAL = sum(a for *_, a in OEWD_LINES)
HPF_LINES = [
    ("F1", "Environmental educator personnel", 5800000),
    ("F2", "Student field-trip transportation", 1600000),
    ("F3", "Field kits, curriculum & student refreshments", 1000000),
    ("F4", "Program evaluation", 600000),
]
HPF_TOTAL = sum(a for *_, a in HPF_LINES)
RECEIPT_OVER = 7500  # receipts for expenditures EXCEEDING $75.00 (contract 7.01)
UNIT_APPROVAL = 500000  # per-unit acquisition cost $5,000.00 or more needs prior approval (6.01)
FLEX_PCT = 15  # contract 4.02
IDC_BP = 1200  # 12% of MTDC (9.01)
FRINGE_BP = 2600  # provisional fringe 26% of C1 (8.01)
MTDC_LINES = ("C1", "C2", "C4", "C5", "C7")
MEAL_CAP = 2000  # $20.00 per member per day incl. tax and tip (5.07)
TIP_CAP_PCT = 20
HPF_RECEIPT = 50000  # $500.00 or more (F.1)
HPF_START = D(5, 1)
DEPLOYMENTS = [(D(5, 18), D(5, 20), "Bear Hollow tributary - live-stake planting"),
               (D(6, 15), D(6, 17), "Upper Kettle Creek - bank stabilization"),
               (D(7, 20), D(7, 22), "Sorrel Flats wetland - invasive removal")]


def contract_pdf(path, title, header, sections, exhibit=None):
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], leading=14)
    h = ParagraphStyle("h", parent=ss["Heading3"], spaceBefore=8)
    lab = ParagraphStyle("s", parent=body, fontSize=9, textColor=colors.red)
    story = [Paragraph(LABEL, lab), Paragraph(title, ss["Title"])]
    story += [Paragraph(x, body) for x in header] + [Spacer(1, 6)]
    for head, paras, table in sections:
        story.append(Paragraph(head, h))
        story += [Paragraph(p, body) for p in paras]
        if table:
            t = Table(table, colWidths=[0.7 * inch, 4.2 * inch, 1.4 * inch])
            t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                                   ("ALIGN", (2, 0), (2, -1), "RIGHT"),
                                   ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]))
            story.append(t)
    if exhibit:
        story.append(Paragraph(exhibit[0], h))
        story += [Paragraph(p, body) for p in exhibit[1]]
    story += [Spacer(1, 10), Paragraph(LABEL + ". Fictional parties; not a real agreement.", lab)]
    SimpleDocTemplate(path, pagesize=letter, title=title, author="synthetic",
                      leftMargin=0.9 * inch, rightMargin=0.9 * inch).build(story)


def budget_table(lines):
    return ([["Line", "Cost category", "Annual amount"]] + [[c, n, money(a)] for c, n, a in lines]
            + [["", "Total", money(sum(a for *_, a in lines))]])


CONTRACT_PDF = f"contract_{OEWD}_westmere_environmental_workforce.pdf"
GRANT_PDF = f"grant_{HPF}_halvorsen_pike_foundation.pdf"


def write_contracts():
    contract_pdf(
        f"{OUT}/{CONTRACT_PDF}",
        f"COST-REIMBURSEMENT SERVICES AGREEMENT {OEWD}",
        [f"<b>Awarding office:</b> {AGENCY}, {STATE} (fictional state office)",
         f"<b>Contractor:</b> {ORG}, {ORG_ADDR}",
         "<b>Program:</b> Kettle Basin Conservation Corps - Young Adult Watershed Workforce Training",
         "<b>Period of performance:</b> April 1, 2026 to March 31, 2027",
         f"<b>Not-to-exceed amount:</b> {money(OEWD_TOTAL)}",
         "<b>Basis of payment:</b> reimbursement of actual allowable cost, invoiced monthly in arrears"],
        [("Article 1 - Period of Performance", [
            "1.01 The period of performance runs from April 1, 2026 through March 31, 2027. Only costs incurred "
            "within that period may be invoiced. The date of a vendor's invoice or of payment does not change when "
            "a cost was incurred."], None),
         ("Article 2 - Statement of Work", [
             "2.01 Contractor will recruit, train and supervise crews of young adults aged 18 to 26 who perform "
             "stream-bank restoration, native planting and invasive-plant removal in the Kettle River basin while "
             "earning industry safety credentials.",
             "2.02 A cost may be charged only if it is reasonable, necessary for the work in 2.01 and allocable to "
             "this Agreement in proportion to the benefit received."], None),
         ("Article 3 - Invoicing and Payment", [
             "3.01 The Office will reimburse allowable cost up to the not-to-exceed amount. No advance payments will be made.",
             "3.02 Contractor submits one invoice per calendar month, no later than 25 days after month end, listing "
             "the cost incurred in that month by budget line and reconciled to Contractor's general ledger.",
             "3.03 Invoiced cost must be actually incurred: paid, or recorded as a liability owed to the vendor. "
             "Refunds, rebates, returns and other credits relating to a charged cost reduce that cost and must be "
             "netted against it; a cost that was refunded to Contractor has not been incurred."], None),
         ("Article 4 - Budget", [
             f"4.01 The approved budget for the period of performance is below. The lines total {money(OEWD_TOTAL)}."],
          budget_table(OEWD_LINES)),
         ("", [
             f"4.02 Cumulative expenditures invoiced on any single budget line may exceed that line's annual amount "
             f"by no more than fifteen percent ({FLEX_PCT}%) unless the parties sign a budget amendment. Cost above "
             "that ceiling will not be reimbursed."], None),
         ("Article 5 - Cost Principles", [
             "5.01 Fines, penalties, citations, late-payment charges and any fees for processing them are not allowable.",
             "5.02 Fundraising costs, donations, sponsorships and tickets or tables at benefit events are not allowable.",
             "5.03 Alcoholic beverages are not allowable.",
             "5.04 Entertainment and amusement costs are not allowable.",
             "5.05 Lobbying and political activity are not allowable.",
             "5.06 Meals are not allowable except as provided in 5.07.",
             "5.07 Meals for corps members on the multi-day field deployments listed in Attachment C are allowable "
             f"on line C3 at actual cost up to {money(MEAL_CAP)} per member per day, including sales tax and a "
             f"gratuity of no more than {TIP_CAP_PCT}% of the pre-tax food bill."], None),
         ("Article 6 - Prior Approval", [
             f"6.01 Any item of equipment whose per-unit acquisition cost is {money(UNIT_APPROVAL)} or more "
             "(including freight, set-up and attachments needed to make it usable) requires the Contract "
             "Administrator's written approval before purchase. Without that approval the cost is not allowable.",
             "6.02 Items with a per-unit acquisition cost below the 6.01 threshold are supplies, chargeable to line C4, "
             "regardless of the number of units bought at one time.",
             "6.03 Travel outside the State of Westmere requires prior written approval."], None),
         ("Article 7 - Supporting Documentation", [
             f"7.01 Contractor keeps an itemized receipt or vendor invoice for each expenditure exceeding "
             f"{money(RECEIPT_OVER)}. An expenditure of {money(RECEIPT_OVER)} or less may be supported by the ledger entry.",
             "7.02 The amount invoiced for a cost must equal the amount on its receipt or vendor invoice.",
             "7.03 Payments made under an executed lease or service agreement filed with the Office are documented "
             "by that agreement; per-payment receipts are not needed.",
             "7.04 Salaries are charged according to the staff allocation schedule filed with the Office and supported "
             "by signed timesheets. Corps member stipends are documented by the biweekly stipend roster.",
             "7.05 A cost may be invoiced only once."], None),
         ("Article 8 - Fringe Benefits", [
             f"8.01 Fringe benefits may be charged to line C2 at the provisional rate of twenty-six percent "
             f"({FRINGE_BP // 100}%) of the salaries charged to line C1 in the same month, by monthly journal entry. "
             "The rate is trued up to actual cost at closeout."], None),
         ("Article 9 - Indirect Cost", [
             f"9.01 Contractor's negotiated indirect rate is twelve percent ({IDC_BP // 100}%) of modified total "
             "direct cost (MTDC). No other rate may be applied.",
             "9.02 For this Agreement, MTDC is the month's direct cost on lines C1, C2, C4, C5 and C7. Participant "
             "support (line C3) and equipment (line C6) are excluded from the base.",
             "9.03 Indirect cost is computed each month on that month's MTDC and charged to line C8."], None),
         ("Article 10 - Records", [
             "10.01 Contractor retains all records for six years after the final invoice and gives the Office access on request."],
          None)],
        exhibit=("Attachment C - Scheduled Multi-Day Field Deployments (first half of the period)",
                 ["; ".join(f"{a:%B %d}-{b:%d, %Y}: {w}" for a, b, w in DEPLOYMENTS) + "."]))

    contract_pdf(
        f"{OUT}/{GRANT_PDF}",
        f"GRANT AWARD LETTER AND TERMS - {HPF}",
        [f"<b>Foundation:</b> {FOUND} (fictional private foundation)",
         f"<b>Grantee:</b> {ORG}, {ORG_ADDR}",
         "<b>Project:</b> Tributary Classroom - watershed field science for students in grades 4-8",
         "<b>Grant term:</b> May 1, 2026 through April 30, 2027",
         f"<b>Award:</b> {money(HPF_TOTAL)}"],
        [("A. Purpose", ["A.1 This award funds Tributary Classroom: field-science days at local streams for "
                         "students in grades 4 through 8 from partner schools, and the classroom curriculum that "
                         "goes with them."], None),
         ("B. Term", ["B.1 Grant funds may be applied only to costs incurred during the grant term. Costs incurred "
                      "before May 1, 2026 may not be charged to the grant."], None),
         ("C. Payment", [
             "C.1 The Foundation pays the award in advance: $55,000.00 on signature of this letter and $35,000.00 "
             "after it accepts the interim report.",
             "C.2 The grantee does not invoice the Foundation or request reimbursement."], None),
         ("D. Budget", ["D.1 The approved budget is:"], budget_table(HPF_LINES)),
         ("", ["D.2 The grantee may move up to twenty percent (20%) of any line to another line without asking."], None),
         ("E. Conditions of Use", [
             "E.1 Grant funds are restricted to Tributary Classroom. They may not pay for general operations, "
             "fundraising, board or governance activities, or the grantee's adult corps workforce program.",
             "E.2 Light snacks and drinks for participating students on field days are allowable on line F3.",
             "E.3 Any item costing more than $2,500.00 per unit needs the Foundation's consent.",
             "E.4 Grant funds may not be used for lobbying or electoral activity."], None),
         ("F. Records", ["F.1 Keep receipts for any single expenditure of $500.00 or more charged to the grant. "
                         "Payroll is supported by timesheets."], None),
         ("G. Reports", ["G.1 Interim narrative and financial report by budget line due November 15, 2026; final "
                         "report due May 31, 2027.",
                         "G.2 Funds not spent on allowable costs by the end of the term are returned to the Foundation."],
          None)])


# ----------------------------------------------------------------------------- GL model
rows = []
receipts = []
seq = {"dd": 7300, "chk": 2200}


def add(d, ttype, num, name, memo, account, cls, loc, cents, split=CHECKING, receipt=None, issue=None, tag=None,
        exempt=False):
    r = dict(date=d, ttype=ttype, num=num, name=name, memo=memo, account=account, cls=cls, loc=loc, split=split,
             cents=cents, receipt=receipt, issue=issue, tag=tag, exempt=exempt)
    rows.append(r)
    return r


def items_total(items, tip=0):
    sub = sum(q * u for _, q, u, *_ in items)
    taxable = sum(q * u for _, q, u, *t in items if (t[0] if t else True))
    tax = tax_of(taxable)
    return sub, tax, sub + tax + tip


def rcpt(fname, vendor, d, items, kind="pdf", doc="RECEIPT", number=None, notes=(), payment=CARD, service=None,
         bill_to=False, tip=0):
    sub, tax, total = items_total(items, tip)
    spec = dict(file=f"receipts/{fname}.{kind}", vendor=vendor, address=addr(), date=d, items=items, sub=sub, tax=tax,
                tip=tip, total=total, kind=kind, doc=doc, number=number or f"{rng.randint(100000, 999999)}",
                notes=list(notes), payment=payment, service=service, bill_to=bill_to)
    receipts.append(spec)
    return spec


def nt(desc, q, u):
    return (desc, q, u, False)


C = lambda line: f"{OEWD}:{line}"
H = lambda line: f"{HPF}:{line}"
FIELD, TC, ADMIN = "Corps Field Operations", "Tributary Classroom", "Administration"

# ---- payroll ---------------------------------------------------------------------------
STAFF = [  # employee, role, biweekly gross, allocation on file, location
    ("M. Okonkwo-Hale", "Corps Director", 315000, [(C("C1"), 60), ("General", 40)], FIELD),
    ("D. Brannigan", "Crew Leader", 208000, [(C("C1"), 100)], FIELD),
    ("S. Ilyina", "Crew Leader", 208000, [(C("C1"), 100)], FIELD),
    ("R. Castellanos", "Environmental Educator", 224000, [(C("C1"), 25), (H("F1"), 75)], TC),
    ("J. Whitcombe", "Development & Communications Manager", 246000, [("General", 100)], ADMIN),
    ("A. Thornquist", "Executive Director", 390000, [("General", 100)], ADMIN),
]
PAYDATES = [D(4, 3), D(4, 17), D(5, 1), D(5, 15), D(5, 29), D(6, 12), D(6, 26), D(7, 10), D(7, 24)]
STIPEND_MEMBERS, STIPEND_EACH = 8, 60000
OT_CENTS = 16 * 3900

for pd in PAYDATES:
    for emp, role, gross, alloc, loc in STAFF:
        seq["dd"] += 1
        num = f"DD{seq['dd']}"
        memo = f"Payroll {mdy(pd)} - biweekly"
        if emp == "J. Whitcombe" and pd == D(6, 12):
            c1 = gross * 25 // 100
            add(pd, "Paycheck", num, emp, memo, "6010 Salaries & Wages", C("C1"), ADMIN, c1, exempt=True,
                issue=dict(kind="payroll_over_allocation", status="needs_review", clause=f"{OEWD} §7.04",
                           note=f"25% ({money(c1)}) of this paycheck is coded to C1, but the allocation on file for this "
                                "employee is UNRESTRICTED=100% (development role, no contract effort on file)."))
            add(pd, "Paycheck", num, emp, memo, "6010 Salaries & Wages", "General", ADMIN, gross - c1)
            continue
        g = gross
        if emp == "D. Brannigan" and pd == D(6, 26):
            g = gross + OT_CENTS
            memo = f"Payroll {mdy(pd)} - biweekly incl. 16.0 hrs OT (Upper Kettle Creek deployment)"
        a = alloc
        if emp == "R. Castellanos" and pd < D(5, 15):  # HPF term starts 05/01; pay through 05/01 is April work
            a = [(C("C1"), 25), ("General", 75)]
        parts, remaining = [], g
        for i, (cls, pct) in enumerate(a):
            c = remaining if i == len(a) - 1 else g * pct // 100
            remaining -= c
            parts.append((cls, c))
        assert sum(c for _, c in parts) == g
        for cls, c in parts:
            tag = None
            if emp == "D. Brannigan" and pd == D(6, 26):
                tag = ("tricky:gross above the biweekly amount on file because of 16 hrs overtime during an Attachment C "
                       "deployment; still 100% C1 per allocation")
            if emp == "R. Castellanos" and pd == D(5, 1) and cls == C("C1"):
                tag = ("tricky:HPF share of pay for pre-May work was kept in unrestricted (grant term starts 05/01); the "
                       "C1 share is exactly the 25% on file")
            add(pd, "Paycheck", num, emp, memo, "6010 Salaries & Wages", cls, loc if cls != "General" else loc, c,
                exempt=True, tag=tag)
    seq["dd"] += 1
    add(pd, "Paycheck", f"DD{seq['dd']}", "Corps Member Stipend Roster",
        f"Corps member stipends {mdy(pd)} - {STIPEND_MEMBERS} members (roster on file)", "6150 Participant Stipends",
        C("C3"), FIELD, STIPEND_MEMBERS * STIPEND_EACH, exempt=True)

# ---- general overhead ------------------------------------------------------------------
for m in (4, 5, 6, 7):
    add(D(m, 1), "Expense", f"ACH{m:02d}01", "Fallowfield Commons LLC", "Office & tool barn rent (lease)",
        "6800 Rent", "General", ADMIN, 265000)
    add(D(m, 7), "Expense", "", "Harrow Ferry Municipal Utilities", f"Electric & water {D(m, 1):%b %Y}",
        "6810 Utilities", "General", ADMIN, rng.randint(24000, 39000))
    add(D(m, 11), "Expense", "", "Pinecrest Broadband", f"Internet & phones {D(m, 1):%b %Y}",
        "6820 Telephone & Internet", "General", ADMIN, 18999)
    add(D(m, 14), "Expense", "", "Ledgerline Cloud", "Accounting software subscription", "6860 Software Subscriptions",
        "General", ADMIN, 9000)
    add(D(m, 28), "Expense", "", "Fernbank Community Bank", "Account analysis fee", "6850 Bank Fees", "General",
        ADMIN, 1800)
seq["chk"] += 1
add(D(4, 15), "Check", str(seq["chk"]), "Granite Shoals Mutual", "Property & liability premium Q2",
    "6830 Insurance", "General", ADMIN, 234000)

# ---- C5 vehicle lease + fleet card -----------------------------------------------------
for m in (4, 5, 6, 7):
    add(D(m, 5), "Expense", f"ACH{m:02d}05", "Alder Fleet Leasing", "Crew truck lease - 2 vehicles (lease AFL-1187 on file)",
        "6500 Vehicle & Field Travel", C("C5"), FIELD, 114000, exempt=True,
        tag="tricky:recurring lease payment under executed lease on file; no per-payment receipt needed (7.03)"
        if m == 4 else None)

FLEET = {}
for m, n in ((4, 7), (5, 9), (6, 8), (7, 9)):
    start = D(m, 1)
    end = D(m, 30) if m in (4, 6) else D(m, 31)
    items = []
    for day in sorted(rng.sample(range(1, end.day + 1), n)):
        gal = rng.randint(140, 230) / 10
        price = rng.choice([399, 405, 412, 419])
        items.append(nt(f"{m:02d}/{day:02d} Ridgeline Fuel #{rng.randint(10, 40)} - {gal:.1f} gal unleaded", 1,
                        rhu(gal * price)))
    sp = rcpt(f"{end.isoformat()}_westmere-fleetcard", "Westmere FleetCard Services", end, items, doc="STATEMENT",
              number=f"FC-26{m:02d}", payment="Due in 15 days", service=f"Statement period: {mdy(start)} - {mdy(end)}",
              bill_to=True, kind="png" if m == 6 else "pdf")
    FLEET[m] = (sp, add(end, "Bill", f"FC-26{m:02d}", "Westmere FleetCard Services", f"FleetCard statement {start:%b %Y}",
                        "6510 Fuel", C("C5"), FIELD, sp["total"], split=AP, receipt=sp))
# duplicate entry of the May statement in June
sp5, _ = FLEET[5]
r_dup = add(D(6, 4), "Bill", "FC2605", "Westmere FleetCard Services", "FleetCard statement May 2026",
            "6510 Fuel", C("C5"), FIELD, sp5["total"], split=AP, receipt=sp5,
            issue=dict(kind="duplicate_charge", status="needs_review", clause=f"{OEWD} §7.05",
                       note=f"May FleetCard statement FC-2605 ({money(sp5['total'])}) is already booked as a bill on "
                            "05/31; re-entered on 06/04 without the hyphen. Bank shows a single payment."))

van_items = [("12-passenger van, per day", 2, 14900), ("Mileage, per mile", 184, 39),
             nt("Parking citation pass-through #HF-40917", 1, 4500), nt("Citation administrative fee", 1, 1500)]
sp = rcpt("2026-05-20_bluestem-van", "Bluestem Truck & Van Rental", D(5, 20), van_items,
          number=f"RA-{rng.randint(50000, 59999)}", notes=["Rental 05/18-05/20/2026 - Bear Hollow deployment",
                                                          "Citation issued 05/19 while vehicle on rental"])
add(D(5, 20), "Expense", "", "Bluestem Truck & Van Rental", "Van rental - Bear Hollow deployment",
    "6500 Vehicle & Field Travel", C("C5"), FIELD, sp["total"], receipt=sp,
    issue=dict(kind="unallowable_line_item", status="blocked", clause=f"{OEWD} §5.01", blocked=6000,
               note="Rental receipt includes a $45.00 parking citation and a $15.00 citation processing fee "
                    "($60.00, untaxed); the van rental and mileage are allowable."))

# ---- C4 field supplies -----------------------------------------------------------------
sp = rcpt("2026-04-08_granger-farm-ranch", "Granger Farm & Ranch Supply", D(4, 8),
          [("Native riparian seed mix, 25 lb", 2, 13900), ("Coir erosion blanket, 4x50 ft", 3, 6450),
           ("Wood stakes, 12 in, bundle/100", 4, 2275)])
add(D(4, 8), "Expense", "", "Granger Farm & Ranch Supply", "Seed, erosion blanket, stakes - spring planting",
    "6400 Field Supplies & Materials", C("C4"), FIELD, sp["total"], receipt=sp)
add(D(4, 20), "Expense", "", "Millbrook Hardware", "Zip ties, tarp grommets", "6400 Field Supplies & Materials",
    C("C4"), FIELD, 4817)
sp = rcpt("2026-04-24_kettle-valley-nursery", "Kettle Valley Nursery", D(4, 24),
          [("Willow live stakes, bundle of 25", 8, 4200)], notes=["Species: Salix exigua / Salix lucida"])
add(D(4, 24), "Expense", "", "Kettle Valley Nursery", "Willow live stakes", "6400 Field Supplies & Materials",
    C("C4"), FIELD, sp["total"], receipt=sp)

bc_items = [("Brushcutter, 2.2 hp straight shaft", 5, 108900), ("Harness & blade kit", 5, 6495)]
sp_bc = rcpt("2026-05-06_cascadia-power", "Cascadia Power Equipment", D(5, 6), bc_items, doc="SALES INVOICE",
             number=f"CPE-{rng.randint(10000, 19999)}")
per_unit = 108900 + 6495 + tax_of(108900 + 6495)
assert per_unit < UNIT_APPROVAL and sp_bc["total"] >= UNIT_APPROVAL
add(D(5, 6), "Expense", "", "Cascadia Power Equipment", "Brushcutters (5) for invasive removal crews",
    "6400 Field Supplies & Materials", C("C4"), FIELD, sp_bc["total"], receipt=sp_bc,
    tag=f"tricky:order total {money(sp_bc['total'])} is above $5,000 but each unit is {money(per_unit)}; "
        "per-unit test in 6.01/6.02 makes these supplies, no prior approval needed")
add(D(5, 14), "Expense", "", "Tolland Lumber Yard", "Lumber - footbridge decking, Bear Hollow",
    "6400 Field Supplies & Materials", C("C4"), FIELD, 21240,
    issue=dict(kind="missing_receipt", status="needs_review", clause=f"{OEWD} §7.01",
               note="$212.40 exceeds the $75.00 documentation threshold; no receipt or invoice in the file."))
sp = rcpt("2026-05-22_summit-workwear", "Summit Workwear", D(5, 22),
          [("Steel-toe work boots", 8, 11900), ("Cut-resistant gloves, pair", 8, 1850), ("Hi-vis safety vest", 8, 1200)],
          notes=["Issued to corps members - PPE log #26-05"])
add(D(5, 22), "Expense", "", "Summit Workwear", "PPE - boots, gloves, vests for corps members",
    "6400 Field Supplies & Materials", C("C4"), FIELD, sp["total"], receipt=sp,
    tag="tricky:clothing-like purchase, but PPE is a program supply per Contract Administrator ruling of 04/21/2026")

sp = rcpt("2026-06-04_granger-farm-ranch", "Granger Farm & Ranch Supply", D(6, 4),
          [("Straw wattles, 9 in x 25 ft", 6, 3895), ("Jute twine, 1 lb", 4, 749), ("Steel T-post, 6 ft", 20, 689)])
s = f"{sp['total'] // 100}"
assert len(s) == 3 and s[1] != s[2]
gl_mis = int(s[0] + s[2] + s[1]) * 100 + sp["total"] % 100
assert gl_mis != sp["total"]
add(D(6, 4), "Expense", "", "Granger Farm & Ranch Supply", "Wattles, twine, T-posts - Upper Kettle Creek",
    "6400 Field Supplies & Materials", C("C4"), FIELD, gl_mis, receipt=sp,
    issue=dict(kind="receipt_amount_mismatch", status="needs_review", clause=f"{OEWD} §7.02",
               note=f"Booked {money(gl_mis)}; the receipt total is {money(sp['total'])} (digits transposed, "
                    f"difference {money(gl_mis - sp['total'])})."))
seq["chk"] += 1
sp = rcpt("2026-06-09_westmere-watershed-alliance", "Westmere Watershed Alliance", D(6, 9),
          [nt("Riverlights Gala - table sponsorship (4 seats, dinner included)", 1, 35000)],
          doc="SPONSORSHIP ACKNOWLEDGMENT", payment=f"Check #{seq['chk']}", bill_to=True,
          notes=["Thank you for sponsoring our annual benefit gala!", "Estimated value of dinner received: $160.00"])
add(D(6, 9), "Check", str(seq["chk"]), "Westmere Watershed Alliance", "Riverlights Gala - table sponsorship",
    "6720 Dues & Sponsorships", C("C4"), FIELD, sp["total"], receipt=sp,
    issue=dict(kind="unallowable_cost", status="blocked", clause=f"{OEWD} §5.02",
               note="Benefit-gala table sponsorship is a fundraising/sponsorship cost; not allowable on the contract."))

cp_items = [("Field guide booklet, 24 pp - Tributary Classroom", 300, 235),
            ("Crew safety sign, coroplast 18x24", 20, 1450)]
sp_cp = rcpt("2026-06-18_copperline-print", "Copperline Print Works", D(6, 18), cp_items, doc="INVOICE",
             number="CPW-7781", bill_to=True, payment="Paid by debit card ****2093")
oewd_sub, hpf_sub = 20 * 1450, 300 * 235
oewd_ok, hpf_ok = oewd_sub + tax_of(oewd_sub), hpf_sub + tax_of(hpf_sub)
assert oewd_ok + hpf_ok == sp_cp["total"], (oewd_ok, hpf_ok, sp_cp["total"])
oewd_bk, hpf_bk = oewd_sub + sp_cp["tax"], hpf_sub + sp_cp["tax"]
assert oewd_bk + hpf_bk - sp_cp["total"] == sp_cp["tax"]
split_memo = "Copperline CPW-7781 split: field guides (HPF) / safety signs (OEWD)"
r_cp_h = add(D(6, 18), "Expense", "", "Copperline Print Works", split_memo, "6420 Printing", H("F3"), TC, hpf_bk,
             receipt=sp_cp, tag="related")
add(D(6, 18), "Expense", "", "Copperline Print Works", split_memo, "6420 Printing", C("C4"), FIELD, oewd_bk,
    receipt=sp_cp,
    issue=dict(kind="split_allocation_mismatch", status="needs_review", clause=f"{OEWD} §7.02 / §2.02",
               note=f"Invoice {money(sp_cp['total'])} split across both funders, but each split row carries the full "
                    f"{money(sp_cp['tax'])} sales tax; the rows total {money(oewd_bk + hpf_bk)}. OEWD's share is "
                    f"signs {money(oewd_sub)} + tax {money(oewd_ok - oewd_sub)} = {money(oewd_ok)}, so C4 is over by "
                    f"{money(oewd_bk - oewd_ok)}. The HPF:F3 row is the mirror error."))
ret_items = [("RETURN Brushcutter, 2.2 hp straight shaft", -1, 108900), ("RETURN Harness & blade kit", -1, 6495)]
sp = rcpt("2026-06-25_cascadia-power-return", "Cascadia Power Equipment", D(6, 25), ret_items, doc="RETURN RECEIPT",
          number=f"RMA-{rng.randint(5000, 5999)}", payment="Refund to debit card ****2093",
          notes=[f"Original invoice {sp_bc['number']} dated 05/06/2026", "Unit returned unused"])
add(D(6, 25), "Deposit", "", "Cascadia Power Equipment", f"Return 1 brushcutter + kit - {sp['number']}",
    "6400 Field Supplies & Materials", C("C4"), FIELD, sp["total"], receipt=sp,
    tag="tricky:negative line is a properly recorded vendor credit netted against C4 (3.03); matches the return receipt and bank credit")

sp = rcpt("2026-06-16_juniper-flats-diner", "Juniper Flats Diner", D(6, 16),
          [("Trail breakfast plate", 3, 1295), ("Veggie scramble", 2, 1250), ("Biscuits & gravy", 2, 1175),
           ("Pancake stack w/ eggs", 1, 1395), ("Coffee / juice", 8, 225)], kind="png",
          number=f"Check {rng.randint(100, 999)} / Party of 8",
          notes=["Kettle Basin Corps - Upper Kettle Creek deployment", "Corps members only (8)"], tip=0)
food = sp["sub"]
tip = food * 18 // 100
sp["tip"], sp["total"] = tip, sp["sub"] + sp["tax"] + tip
assert sp["total"] <= MEAL_CAP * 8 and tip * 100 <= TIP_CAP_PCT * food
add(D(6, 16), "Expense", "", "Juniper Flats Diner", "Corps member breakfast - Upper Kettle Creek deployment day 2",
    "6160 Participant Meals", C("C3"), FIELD, sp["total"], receipt=sp,
    tag=f"tricky:meal is allowable under 5.07 - Attachment C deployment, {money(sp['total'] // 8)}/member incl. "
        f"tax and an 18% tip, under the $20.00 and 20% caps")

sp = rcpt("2026-07-07_northfork-outfitters", "Northfork Outfitters", D(7, 7),
          [("Chest waders, breathable, assorted sizes", 6, 10995)], number=f"NFO-{rng.randint(300000, 399999)}")
r_ref = add(D(7, 7), "Expense", "", "Northfork Outfitters", "Chest waders - stream crew (6)",
            "6400 Field Supplies & Materials", C("C4"), FIELD, sp["total"], receipt=sp,
            issue=dict(kind="refund_not_recorded", status="blocked", clause=f"{OEWD} §3.03",
                       note=f"Bank shows the {money(sp['total'])} card purchase on 07/08 and a full refund from the same "
                            "vendor on 07/13; the ledger has no matching credit, so the cost was not incurred."))
REFUND = (D(7, 13), "DEBIT CARD CREDIT NORTHFORK OUTFITTERS", sp["total"])
add(D(7, 16), "Expense", "", "Tri-County Transfer Station", "Green waste disposal - Sorrel Flats prep",
    "6400 Field Supplies & Materials", C("C4"), FIELD, 7500,
    tag="tricky:exactly $75.00 with no receipt; 7.01 requires receipts only for expenditures exceeding $75.00")
add(D(7, 21), "Expense", "", "Millbrook Hardware", "Loppers sharpening, bolts", "6400 Field Supplies & Materials",
    C("C4"), FIELD, 6390)
sp = rcpt("2026-07-28_granger-farm-ranch", "Granger Farm & Ranch Supply", D(7, 28),
          [("Native plant plugs, 50-cell tray", 12, 7400), nt("Delivery to Sorrel Flats site", 1, 6500)],
          doc="INVOICE", number=f"GFR-{rng.randint(80000, 89999)}", payment="Terms: Net 30", bill_to=True)
add(D(7, 28), "Bill", sp["number"], "Granger Farm & Ranch Supply", "Plant plugs - Sorrel Flats (on account)",
    "6400 Field Supplies & Materials", C("C4"), FIELD, sp["total"], split=AP, receipt=sp,
    tag="tricky:unpaid at statement end (no bank debit yet); accrued liability counts as incurred under 3.03")

# ---- C6 equipment ----------------------------------------------------------------------
seq["chk"] += 1
sp = rcpt("2026-06-12_harlan-trailer", "Harlan Trailer Works", D(6, 12),
          [("16 ft tandem-axle equipment trailer w/ ramp gate", 1, 618000), nt("Freight & dealer prep", 1, 29500)],
          doc="SALES INVOICE", number=f"HTW-{rng.randint(2000, 2999)}", payment=f"Check #{seq['chk']}", bill_to=True)
assert sp["total"] >= UNIT_APPROVAL
add(D(6, 12), "Check", str(seq["chk"]), "Harlan Trailer Works", "Equipment trailer - crew tools", "6600 Equipment",
    C("C6"), FIELD, sp["total"], receipt=sp,
    issue=dict(kind="missing_prior_approval", status="blocked", clause=f"{OEWD} §6.01",
               note=f"Single trailer at {money(sp['total'])} incl. freight (per-unit >= $5,000.00); no written approval "
                    "from the Contract Administrator in the memo or precedents."))

# ---- C7 training -----------------------------------------------------------------------
c7 = []
for d, v, fn, desc, q, u in ((D(4, 14), "Cairn Wilderness Medicine", "cairn-wilderness", "Wilderness First Aid, 16 hrs", 8, 27000),
                             (D(5, 12), "Oakhurst Arborist Academy", "oakhurst-arborist", "Chainsaw safety & felling, Level 1", 6, 47500),
                             (D(6, 23), "Tri-Valley Applicator Training", "trivalley-applicator", "Herbicide applicator exam prep", 4, 31000),
                             (D(7, 15), "Riverwise Rescue Training", "riverwise-rescue", "Swiftwater awareness, 8 hrs", 8, 19750)):
    inv = f"{''.join(w[0] for w in v.split()[:2])}-{rng.randint(1000, 9999)}"
    sp = rcpt(f"{d.isoformat()}_{fn}", v, d, [nt(f"{desc} - per participant", q, u)], doc="INVOICE", number=inv,
              payment="Terms: Net 15", bill_to=True, service=f"Course date(s): {mdy(d - timedelta(days=2))}")
    c7.append(add(d, "Bill", inv, v, f"{desc} - corps members ({q})", "6700 Training & Certifications", C("C7"),
                  FIELD, sp["total"], split=AP, receipt=sp))
c7_cap = 600000 * (100 + FLEX_PCT) // 100
cum = 0
for r in c7:
    before, cum = cum, cum + r["cents"]
    if before <= c7_cap < cum:
        assert r is c7[-1]
        r["issue"] = dict(kind="line_overrun", status="blocked", clause=f"{OEWD} §4.02", blocked=cum - c7_cap,
                          note=f"Cumulative C7 cost reaches {money(cum)} against the {money(600000)} line + 15% = "
                               f"{money(c7_cap)}; {money(cum - c7_cap)} of this invoice is above the ceiling.")
assert c7[-1]["issue"]

# ---- HPF direct costs ------------------------------------------------------------------
sp = rcpt("2026-04-22_brightwater-craft", "Brightwater Craft & Party", D(4, 22),
          [("Tri-fold display board", 4, 1299), ("Poster marker set", 3, 1849), ("Seed-ball craft kit", 40, 425),
           ("Custom table banner", 1, 3900)], kind="png", notes=["Harrow Ferry Earth Day festival booth"])
add(D(4, 22), "Expense", "", "Brightwater Craft & Party", "Earth Day booth supplies - Tributary Classroom",
    "6410 Curriculum & Field Kits", H("F3"), TC, sp["total"], receipt=sp,
    issue=dict(kind="out_of_period", status="blocked", clause=f"{HPF} §B.1",
               note="Purchased 04/22/2026, before the grant term began 05/01/2026; cannot be charged to the "
                    "advance-paid grant (move to unrestricted)."))
for d, n in ((D(5, 13), 1), (D(6, 3), 2)):
    sp = rcpt(f"{d.isoformat()}_lakeshore-charter", "Lakeshore Charter Coach", d,
              [nt("56-passenger coach, 6-hr school charter", n, 114000)], doc="INVOICE",
              number=f"LCC-{rng.randint(40000, 49999)}", bill_to=True,
              notes=[f"Field day: {'Harrow Ferry Middle School grade 6' if n == 1 else 'Oxley Mills Elementary grades 4-5'}"])
    add(d, "Expense", "", "Lakeshore Charter Coach", "Student field-day bus charter", "6450 Student Transportation",
        H("F2"), TC, sp["total"], receipt=sp)
sp = rcpt("2026-05-20_tributary-science", "Tributary Science Supply", D(5, 20),
          [("Stream macroinvertebrate field kit", 6, 8900), ("Water chemistry test strips (100)", 6, 2450),
           ("D-frame dip net", 6, 3175)])
add(D(5, 20), "Expense", "", "Tributary Science Supply", "Student field kits", "6410 Curriculum & Field Kits",
    H("F3"), TC, sp["total"], receipt=sp)
sp = rcpt("2026-06-03_pinewood-market", "Pinewood Market", D(6, 3),
          [("Granola bars, 24 ct", 4, 1199), ("Apple slices snack packs, 12 ct", 5, 899), ("Water bottles, 24 pk", 4, 549),
           nt("Juice boxes, 32 ct", 2, 1349)], kind="png", notes=["Snacks - Oxley Mills Elementary field day"])
add(D(6, 3), "Expense", "", "Pinewood Market", "Student snacks - field day", "6460 Student Refreshments", H("F3"), TC,
    sp["total"], receipt=sp,
    tag="tricky:food on a restricted grant, but E.2 allows light snacks for students on field days")
add(D(6, 29), "Expense", "", "Riverside Copy Center", "Student worksheets - stream monitoring unit",
    "6420 Printing", H("F3"), TC, 9640)
sp = rcpt("2026-07-09_lantern-hill", "Lantern Hill Facilitation Group", D(7, 9),
          [nt("Facilitation - Board of Directors strategy retreat, 07/08/2026 (6 hrs)", 1, 120000),
           nt("Retreat materials & session notes", 1, 15000)], doc="INVOICE", number=f"LHF-{rng.randint(100, 999)}",
          payment="Terms: Net 15", bill_to=True)
add(D(7, 9), "Bill", sp["number"], "Lantern Hill Facilitation Group", "Retreat facilitation", "6310 Professional Services",
    H("F4"), TC, sp["total"], split=AP, receipt=sp,
    issue=dict(kind="restricted_purpose_misuse", status="blocked", clause=f"{HPF} §E.1",
               note="Invoice is for a board strategy retreat (governance), charged to the Tributary Classroom "
                    "evaluation line; the restricted grant excludes board/governance costs."))
sp = rcpt("2026-07-14_tributary-science", "Tributary Science Supply", D(7, 14),
          [("Hand lens, 10x", 30, 695), ("Student field journal", 120, 240)])
add(D(7, 14), "Expense", "", "Tributary Science Supply", "Hand lenses & field journals", "6410 Curriculum & Field Kits",
    H("F3"), TC, sp["total"], receipt=sp)
sp = rcpt("2026-07-30_northbank-evaluation", "Northbank Evaluation Partners", D(7, 30),
          [nt("Student pre/post survey design & baseline analysis", 1, 150000)], doc="INVOICE",
          number=f"NEP-{rng.randint(1000, 9999)}", payment="Terms: Net 30", bill_to=True)
add(D(7, 30), "Bill", sp["number"], "Northbank Evaluation Partners", "Evaluation - baseline student survey",
    "6310 Professional Services", H("F4"), TC, sp["total"], split=AP, receipt=sp)


# ---- month-end JEs ---------------------------------------------------------------------
def in_month(r, m):
    return r["date"].month == m


MONTH_END = {4: D(4, 30), 5: D(5, 31), 6: D(6, 30), 7: D(7, 31)}
for m, d in MONTH_END.items():
    c1 = sum(r["cents"] for r in rows if in_month(r, m) and r["cls"] == C("C1"))
    other = sum(r["cents"] for r in rows if in_month(r, m) and r["account"] == "6010 Salaries & Wages"
                and not r["cls"].startswith(f"{OEWD}:"))
    fr = rhu(c1 * FRINGE_BP / 10000)
    add(d, "Journal Entry", f"JE-FB-{m:02d}", "", f"Fringe 26% provisional x C1 wages {money(c1)}",
        "6100 Payroll Taxes & Benefits", C("C2"), FIELD, fr, split="2100 Payroll Liabilities", exempt=True,
        tag="tricky:journal entry with no receipt; documented by the 26% provisional rate in 8.01" if m == 5 else None)
    add(d, "Journal Entry", f"JE-FB-{m:02d}", "", "Fringe 26% provisional - other staff",
        "6100 Payroll Taxes & Benefits", "General", ADMIN, rhu(other * FRINGE_BP / 10000),
        split="2100 Payroll Liabilities")

IDC = {}
for m, d in MONTH_END.items():
    mtdc = sum(r["cents"] for r in rows if in_month(r, m) and r["cls"].startswith(f"{OEWD}:")
               and r["cls"].split(":")[1] in MTDC_LINES)
    allowed = rhu(mtdc * IDC_BP / 10000)
    if m == 6:
        booked = rhu(mtdc * 1500 / 10000)
        memo = f"Indirect 15% x Jun MTDC {money(mtdc)}"
        issue = dict(kind="indirect_wrong_rate", status="blocked", clause=f"{OEWD} §9.01-9.03", blocked=booked - allowed,
                     note=f"June indirect booked at 15% (de minimis rate) instead of the negotiated 12%. Allowed = 12% x "
                          f"MTDC {money(mtdc)} = {money(allowed)}; excess {money(booked - allowed)}.")
        tag = None
    else:
        booked, memo, issue = allowed, f"Indirect 12% x {d:%b} MTDC {money(mtdc)}", None
        tag = ("tricky:base correctly excludes C3 stipends/meals and C6; 12% x MTDC ties to the cent" if m == 4 else None)
    assert booked - allowed == (issue["blocked"] if issue else 0)
    IDC[m] = (mtdc, allowed, booked)
    add(d, "Journal Entry", f"JE-IDC-{m:02d}", "", memo, "6900 Indirect Cost Allocation", C("C8"), ADMIN, booked,
        split="6990 Indirect Cost Recovery", issue=issue, exempt=True, tag=tag)

rows.sort(key=lambda r: (r["date"], r["ttype"] != "Paycheck", r["num"], r["name"], r["cls"]))


# ---- self-checks -----------------------------------------------------------------------
def selfcheck():
    norm = lambda s: re.sub(r"[^a-z0-9]", "", s.lower())
    keys = [(r["date"], norm(r["num"]), norm(r["name"]), r["cents"], r["cls"]) for r in rows]
    assert len(keys) == len(set(keys)), "GL rows not uniquely addressable"
    for r in rows:  # documentation rules hold except where an issue is planted
        if r["cls"].startswith(f"{OEWD}:") and abs(r["cents"]) > RECEIPT_OVER and not r["exempt"]:
            assert r["receipt"] or (r["issue"] and r["issue"]["kind"] == "missing_receipt"), r
        if r["cls"].startswith(f"{HPF}:") and r["cents"] >= HPF_RECEIPT and not r["exempt"]:
            assert r["receipt"], r
        if r["receipt"] and not r["issue"] and r["tag"] != "related":
            assert r["receipt"]["total"] == r["cents"], (r["name"], r["receipt"]["total"], r["cents"])
        if r["cls"].startswith(f"{HPF}:"):
            assert r["date"] >= HPF_START or r["issue"], r
    for pd in PAYDATES:  # payroll parts tie to gross
        for emp, _, gross, *_ in STAFF:
            got = sum(r["cents"] for r in rows if r["ttype"] == "Paycheck" and r["date"] == pd and r["name"] == emp)
            exp = gross + (OT_CENTS if (emp == "D. Brannigan" and pd == D(6, 26)) else 0)
            assert got == exp, (emp, pd, got, exp)
    for code, _, budget in OEWD_LINES:  # no unplanned line overruns
        tot = sum(r["cents"] for r in rows if r["cls"] == C(code))
        assert tot <= budget * (100 + FLEX_PCT) // 100 or code == "C7", (code, tot)
    for code, _, budget in HPF_LINES:
        assert sum(r["cents"] for r in rows if r["cls"] == H(code)) <= budget


# ----------------------------------------------------------------------------- receipts render
def render_pdf_receipt(sp):
    lines = [("B", sp["vendor"]), ("", sp["address"]), ("", ""), ("B", sp["doc"]), ("", f"No. {sp['number']}"),
             ("", f"Date: {mdy(sp['date'])}")]
    if sp["bill_to"]:
        lines += [("", f"Bill to: {ORG}"), ("", ORG_ADDR)]
    if sp["service"]:
        lines.append(("", sp["service"]))
    lines.append(("", "-" * 56))
    for desc, q, u, *t in sp["items"]:
        lines.append(("I", (desc, q, u, q * u)))
    lines.append(("", "-" * 56))
    lines.append(("T", ("Subtotal", sp["sub"])))
    if sp["tax"]:
        lines.append(("T", (f"Sales tax {TAX_BP / 100:.2f}%", sp["tax"])))
    if sp["tip"]:
        lines.append(("T", ("Gratuity", sp["tip"])))
    lines.append(("TB", ("TOTAL" if sp["total"] >= 0 else "REFUND TOTAL", sp["total"])))
    lines += [("", ""), ("", f"Payment: {sp['payment']}")] + [("", n) for n in sp["notes"]] + [("", ""), ("", "Thank you.")]
    W = 4.8 * inch
    Ht = (2.0 + 0.22 * len(lines) + 0.3 * sum(1 for k, _ in lines if k == "I")) * inch
    c = canvas.Canvas(f"{OUT}/{sp['file']}", pagesize=(W, Ht), invariant=1)
    c.setTitle(f"{sp['vendor']} {sp['doc'].lower()} {sp['number']}")
    c.setFillColor(colors.red)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(14, Ht - 18, LABEL)
    c.setFillColor(colors.black)
    y = Ht - 42
    for k, v in lines:
        if k == "B":
            c.setFont("Helvetica-Bold", 11)
            c.drawString(14, y, v)
        elif k == "I":
            desc, q, u, ext = v
            c.setFont("Helvetica", 8.5)
            c.drawString(14, y, desc[:64])
            y -= 12
            c.drawString(26, y, f"{q} @ {u / 100:,.2f}")
            c.drawRightString(W - 14, y, f"{ext / 100:,.2f}")
        elif k in ("T", "TB"):
            c.setFont("Helvetica-Bold" if k == "TB" else "Helvetica", 9.5)
            c.drawString(150, y, v[0])
            c.drawRightString(W - 14, y, f"{v[1] / 100:,.2f}")
        else:
            c.setFont("Helvetica", 8.5)
            c.drawString(14, y, v)
        y -= 14
    c.setFont("Helvetica-Oblique", 7)
    c.setFillColor(colors.grey)
    c.drawString(14, 12, LABEL)
    c.showPage()
    c.save()


def render_png_receipt(sp):
    try:
        font = ImageFont.load_default(size=17)
        big = ImageFont.load_default(size=21)
    except TypeError:
        font = big = ImageFont.load_default()
    txt = [(big, sp["vendor"]), (font, sp["address"]), (font, ""), (big, sp["doc"]), (font, f"No. {sp['number']}"),
           (font, f"Date: {mdy(sp['date'])}")]
    if sp["service"]:
        txt.append((font, sp["service"]))
    txt.append((font, "-" * 44))
    for desc, q, u, *t in sp["items"]:
        txt.append((font, desc[:48]))
        txt.append((font, f"   {q} @ {u / 100:,.2f}    {q * u / 100:>10,.2f}"))
    txt += [(font, "-" * 44), (font, f"Subtotal          {sp['sub'] / 100:>10,.2f}")]
    if sp["tax"]:
        txt.append((font, f"Tax {TAX_BP / 100:.2f}%         {sp['tax'] / 100:>10,.2f}"))
    if sp["tip"]:
        txt.append((font, f"Tip               {sp['tip'] / 100:>10,.2f}"))
    txt += [(big, f"TOTAL  {sp['total'] / 100:,.2f}"), (font, ""), (font, f"Payment: {sp['payment']}")]
    txt += [(font, n) for n in sp["notes"]] + [(font, ""), (font, "SYNTHETIC - generated for testing")]
    W, Ht = 600, 70 + 27 * len(txt)
    img = Image.new("RGB", (W, Ht), (247, 245, 238))
    dr = ImageDraw.Draw(img)
    dr.text((20, 16), "SYNTHETIC - generated for testing", fill=(200, 0, 0), font=font)
    y = 50
    for f, s_ in txt:
        dr.text((20, y), s_, fill=(30, 30, 30), font=f)
        y += 27
    bg = Image.new("RGB", (W + 80, Ht + 80), (96, 104, 112))
    bg.paste(img, (40, 40))
    bg = bg.rotate(-1.4, resample=Image.BICUBIC, fillcolor=(96, 104, 112))
    bg.save(f"{OUT}/{sp['file']}", format="PNG", optimize=False)


# ----------------------------------------------------------------------------- answer key
def gl_ref(r):
    return dict(date=mdy(r["date"]), num=r["num"], name=r["name"], amount=amt(r["cents"]))


def build_key():
    issues, clean, n = [], [], 0
    for r in rows:
        if r["issue"]:
            n += 1
            it = r["issue"]
            e = dict(id=f"H4-{n:02d}", kind=it["kind"], glRef=gl_ref(r), cls=r["cls"], expectedStatus=it["status"],
                     clause=it["clause"], note=it["note"])
            if it["status"] == "blocked":
                e["blockedCents"] = it.get("blocked", r["cents"])
            if it["kind"] == "split_allocation_mismatch":
                e["relatedRefs"] = [dict(gl_ref(r_cp_h), cls=r_cp_h["cls"])]
            if it["kind"] == "indirect_wrong_rate":
                mt, al, bk = IDC[6]
                e["correctIndirectCents"], e["bookedIndirectCents"] = al, bk
            issues.append(e)
        elif r["cls"] != "General" and r["tag"] != "related":
            c = dict(date=mdy(r["date"]), num=r["num"], name=r["name"], amount=amt(r["cents"]), **{"class": r["cls"]})
            if r["tag"] and r["tag"].startswith("tricky:"):
                c["note"] = r["tag"][7:]
            clean.append(c)
    conv = (f"Package = every GL row with Class {OEWD}:* whose GL date falls in the month. Clean and needs_review rows "
            "count at their booked amount (negative credits included). Blocked rows are removed in full, except "
            "line_overrun, indirect_wrong_rate and unallowable_line_item, where only blockedCents is removed. Allowed "
            "indirect = 12% of the month's booked MTDC (C1, C2, C4, C5, C7 at booked amounts, not reduced for other "
            "findings). The C7 ceiling is measured on cumulative booked C7 since 04/01/2026 vs $6,000.00 x 115%.")
    packages = []
    for m in (4, 5, 6, 7):
        booked = sum(r["cents"] for r in rows if in_month(r, m) and r["cls"].startswith(f"{OEWD}:"))
        removed = sum(r["issue"].get("blocked", r["cents"]) for r in rows if in_month(r, m)
                      and r["cls"].startswith(f"{OEWD}:") and r["issue"] and r["issue"]["status"] == "blocked")
        tot = 0
        for r in rows:
            if not in_month(r, m) or not r["cls"].startswith(f"{OEWD}:"):
                continue
            it = r["issue"]
            tot += r["cents"] - (it.get("blocked", r["cents"]) if it and it["status"] == "blocked" else 0)
        assert tot == booked - removed
        by_line = {}
        for r in rows:
            if in_month(r, m) and r["cls"].startswith(f"{OEWD}:"):
                by_line[r["cls"]] = by_line.get(r["cls"], 0) + r["cents"]
        assert sum(by_line.values()) == booked
        packages.append(dict(grant=OEWD, period=f"2026-{m:02d}", glBookedTotalCents=booked,
                             expectedInvoiceTotalCents=tot, conventions=conv))
    return dict(version="holdout-v4", seed=SEED, org=ORG,
                grants=[dict(id=OEWD, funder=AGENCY, basis="cost_reimbursement", billing="monthly", total=amt(OEWD_TOTAL)),
                        dict(id=HPF, funder=FOUND, basis="advance", billing="none (interim and final reports)",
                             total=amt(HPF_TOTAL))],
                statusConvention="blocked = cannot be billed or charged as booked (unallowable, out of period, missing "
                                 "prior approval, above the line ceiling, wrong indirect rate, cost refunded, restricted "
                                 "purpose; partial where blockedCents is given). needs_review = fixable question "
                                 "(missing or mismatched receipt, duplicate entry, payroll allocation, split allocation).",
                issues=issues, clean=clean, packages=packages,
                notes=[f"No packages for {HPF} (paid in advance); its findings are restriction findings only.",
                       "Fringe JEs are 26% of booked C1 wages, including the over-allocated paycheck; that matches 8.01, so clean.",
                       "The duplicate FleetCard bill is needs_review and therefore counts in the June package at booked amount.",
                       "General-class rows are unrestricted and not listed in clean."])


# ----------------------------------------------------------------------------- writers
GL_FILE = "gl_transaction_detail_by_account.csv"


def write_gl():
    with open(f"{OUT}/{GL_FILE}", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow([ORG])
        w.writerow(["Transaction Detail by Account"])
        w.writerow(["April 1 - July 31, 2026"])
        w.writerow([])
        w.writerow(["Date", "Transaction Type", "Num", "Name", "Memo/Description", "Account", "Class", "Location",
                    "Split", "Amount", "Balance"])
        accounts = sorted({r["account"] for r in rows})
        grand = 0
        for acct in accounts:
            w.writerow([acct, "", "", "", "", "", "", "", "", "", ""])
            bal = 0
            for r in sorted((r for r in rows if r["account"] == acct), key=lambda r: (r["date"], r["num"], r["cls"])):
                bal += r["cents"]
                w.writerow([mdy(r["date"]), r["ttype"], r["num"], r["name"], r["memo"], r["account"], r["cls"],
                            r["loc"], r["split"], amt(r["cents"]), amt(bal)])
            w.writerow([f"Total for {acct}", "", "", "", "", "", "", "", "", amt(bal), ""])
            grand += bal
        w.writerow(["TOTAL", "", "", "", "", "", "", "", "", amt(grand), ""])
        w.writerow([])
        w.writerow([])
        w.writerow([f"Accrual Basis  Monday, August 10, 2026  09:42 AM GMT-07:00 -- {LABEL}. Fictional data."])


def write_bank():
    out = [(D(4, 1), "ONLINE TRANSFER FROM SAVINGS XXXX4471", 9000000, "Operating reserve draw"),
           (D(5, 8), f"DEPOSIT {FOUND.upper()}", 5500000, f"Grant {HPF} first installment (advance)"),
           (D(6, 2), "REMOTE DEPOSIT", 418500, "Individual donations batch 06-01"),
           (D(7, 1), "ONLINE TRANSFER FROM SAVINGS XXXX4471", 6000000, "Operating reserve draw")]
    for pd in PAYDATES:
        tot = sum(r["cents"] for r in rows if r["ttype"] == "Paycheck" and r["date"] == pd)
        out.append((pd, "HARBORPAY PAYROLL FUNDING", -tot, f"Payroll {mdy(pd)}"))
    seen = set()
    for r in rows:
        key = (r["date"], r["num"], r["name"], r["ttype"])
        if r["ttype"] in ("Expense", "Check", "Deposit") and r["split"] == CHECKING and key not in seen:
            seen.add(key)
            tot = sum(x["cents"] for x in rows if (x["date"], x["num"], x["name"], x["ttype"]) == key)
            if r["ttype"] == "Check":
                desc, d = f"CHECK {r['num']}", r["date"] + timedelta(days=rng.randint(2, 6))
            elif r["ttype"] == "Deposit":
                desc, d = f"DEBIT CARD CREDIT {r['name'].upper()[:28]}", r["date"] + timedelta(days=1)
            elif r["account"] == "6850 Bank Fees":
                desc, d = "ACCOUNT ANALYSIS FEE", r["date"]
            elif r["num"].startswith("ACH"):
                desc, d = f"ACH DEBIT {r['name'].upper()}", r["date"]
            else:
                desc, d = f"DEBIT CARD PURCHASE {r['name'].upper()[:28]}", r["date"] + timedelta(days=1)
            out.append((d, desc, -tot, ""))
    out.append((REFUND[0], REFUND[1], REFUND[2], ""))
    for r in rows:
        if r["ttype"] == "Bill" and r is not r_dup:
            d = r["date"] + timedelta(days=15)
            if d <= D(7, 31):
                out.append((d, f"BILL PMT {r['name'].upper()}", -r["cents"], f"Inv {r['num']}"))
    out.sort(key=lambda x: (x[0], x[1]))
    with open(f"{OUT}/bank_statement.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Posting Date", "Description", "Amount", "Memo"])
        for d, desc, c, memo in out:
            w.writerow([mdy(d), desc, amt(c), memo])
    return len(out)


def write_misc(n_bank):
    with open(f"{OUT}/staff_allocation.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["employee", "role", "biweekly_gross_usd", "allocation"])
        for emp, role, gross, alloc, _ in STAFF:
            w.writerow([emp, role, amt(gross), ";".join(f"{'UNRESTRICTED' if c == 'General' else c}={p}%" for c, p in alloc)])
    prec = [dict(date="2026-04-21", by=f"K. Ostrander, Contract Administrator, {AGENCY}",
                 ruling="Personal protective equipment issued to corps members for field work (safety boots, "
                        "cut-resistant gloves, high-visibility vests) is a necessary program supply allowable on line "
                        "C4. It is not treated as a gift or personal clothing.",
                 scope=f"{OEWD}:C4"),
            dict(date="2026-05-04", by=f"K. Ostrander, Contract Administrator, {AGENCY}",
                 ruling="Biweekly corps member stipends paid under the stipend roster are participant support costs on "
                        "line C3 and stay outside the MTDC base described in Article 9.",
                 scope=f"{OEWD}:C3"),
            dict(date="2026-05-27", by=f"L. Achterberg, Program Officer, {FOUND}",
                 ruling="Partner-school field days may combine two classes on one bus charter; the full charter "
                        "cost is chargeable to line F2.",
                 scope=f"{HPF}:F2")]
    with open(f"{OUT}/precedents.json", "w") as f:
        json.dump(prec, f, indent=2)
    with open(f"{OUT}/README.md", "w") as f:
        f.write(f"""# Steward hold-out v4 (SEALED)

**{LABEL}.** Every organization, agency, foundation, person, vendor, address and amount here is fictional.

**SEALED: do not open while changing detection logic; score once.**

Org: {ORG} (young-adult conservation corps doing watershed restoration, plus a school field-science program).
Period: April-July 2026. Funders: {AGENCY} (fictional state office; cost-reimbursement contract {OEWD},
invoiced monthly) and the {FOUND} (fictional private foundation; grant {HPF}, paid in advance, no invoices).

| File | What |
|---|---|
| `{CONTRACT_PDF}` | State contract, cost-reimbursement, monthly invoices |
| `{GRANT_PDF}` | Foundation grant paid in advance, interim and final reports |
| `{GL_FILE}` | QuickBooks Online "Transaction Detail by Account" export ({len(rows)} transaction lines, grouped by account with totals) |
| `bank_statement.csv` | Checking account activity ({n_bank} lines) |
| `staff_allocation.csv` | Payroll allocation schedule on file |
| `precedents.json` | Funder rulings on file |
| `receipts/` | {len(receipts)} receipts, invoices and statements (PDF, plus {sum(1 for s in receipts if s['kind'] == 'png')} PNG photos) |
| `expected_v4.json` | Answer key (issues, clean lines, expected invoice package totals). Scorer-only. |
| `_generator/generate_holdout_v4.py` | The generator (inside the sealed zip only) |

Regenerate (deterministic, seed {SEED}):

```
uv run --with reportlab --with faker --with pillow python steward-holdout-v4/_generator/generate_holdout_v4.py --out <dir> --zip <dir>/steward-holdout-v4-SEALED.zip --keep
```

Score: `npx tsx scripts/eval-v2-dev.ts --dir steward-holdout-v4`.
""")


def zip_dir():
    gen_src = os.path.abspath(__file__)
    files = []
    for dp, _, fns in os.walk(OUT):
        for fn in fns:
            files.append(os.path.relpath(os.path.join(dp, fn), OUT))
    files = sorted(f for f in files if not f.startswith("_generator"))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def put(arc, data):
            zi = zipfile.ZipInfo(arc, date_time=(2026, 8, 10, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data)
        for rel in files:
            with open(os.path.join(OUT, rel), "rb") as fh:
                put(f"steward-holdout-v4/{rel}", fh.read())
        with open(gen_src, "rb") as fh:
            put("steward-holdout-v4/_generator/generate_holdout_v4.py", fh.read())
    data = buf.getvalue()
    with open(ZIP, "wb") as fh:
        fh.write(data)
    return hashlib.sha256(data).hexdigest()


def main():
    selfcheck()
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    os.makedirs(f"{OUT}/receipts")
    write_contracts()
    for sp in receipts:
        (render_png_receipt if sp["kind"] == "png" else render_pdf_receipt)(sp)
    write_gl()
    n_bank = write_bank()
    write_misc(n_bank)
    key = build_key()
    with open(f"{OUT}/expected_v4.json", "w") as f:
        json.dump(key, f, indent=2)
    digest = zip_dir()
    if "--keep" not in sys.argv:
        shutil.rmtree(OUT)
    print(f"gl_lines={len(rows)} bank_lines={n_bank} receipts={len(receipts)} "
          f"png={sum(1 for s in receipts if s['kind'] == 'png')} issues={len(key['issues'])} clean={len(key['clean'])} "
          f"packages={len(key['packages'])}")
    print(f"sha256 {digest}  {ZIP}")


if __name__ == "__main__":
    main()
