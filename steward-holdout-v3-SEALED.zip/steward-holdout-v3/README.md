# Steward hold-out v3 (SEALED)

**SYNTHETIC — generated for testing.** Every organization, agency, foundation, person, vendor, address and amount here is fictional.
Do not open this set while changing detection logic; score it once.

Org: Cedar Hollow Refugee Welcome Center (refugee resettlement). Period: July-October 2026.

| File | What |
|---|---|
| `contract_NONA-27-0193_state_new_americans.pdf` | Fictional state agency contract, cost-reimbursement, monthly invoices |
| `grant_LAFF-2026-14_linden_ash_foundation.pdf` | Fictional foundation grant paid in advance, semiannual report, no invoices |
| `gl_transaction_detail_by_account.csv` | QuickBooks Online "Transaction Detail by Account" export (136 lines) |
| `receipts/` | 29 receipts/invoices (PDF, plus a few PNG photos) |
| `bank_statement.csv` | Checking account activity |
| `staff_allocation.csv` | Payroll allocation on file |
| `precedents.json` | Funder rulings on file |
| `expected_v3.json` | Answer key (issues, clean lines, expected invoice package totals). Scorer-only. |

Regenerate: `uv run --with reportlab --with faker python scripts/generate_holdout_v3.py` (deterministic, seed 30319).
