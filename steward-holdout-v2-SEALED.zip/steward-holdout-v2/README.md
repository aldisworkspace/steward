# steward-holdout-v2 — SEALED hold-out set

> **SYNTHETIC — generated for testing.** All parties, people, receipts and amounts are fictional.

Written before any tuning of Steward v2, from the same generator as `steward-data-v2/` but with a different
seed, organization, funders, vendors, clause numbering, thresholds and issue forms. Do not tune on it.

- Organization: **Northfen Youth Athletics League** (fictional youth sports nonprofit), FY July 2026 – June 2027,
  billing months July – October 2026.
- `agreement_county_YR-27-0093.pdf` — County of Marrow Bay (fictional) Office of Youth Recreation cost-reimbursement agreement,
  $150,000, monthly invoices, lines Y1–Y7.
- `grant_foundation_QL-26-052.pdf` — Quenby Lark Foundation (fictional) restricted grant, $60,000, lines Q1–Q4.
- `expected_v2.json` — answer key (planted issues, clean rows, package totals).

## `gl_detail_qb.csv` conventions

Flattened QuickBooks Online **Transaction Detail by Account** export (report range 06/01/2026–10/31/2026).
The account group header rows and "Total for …" subtotal rows that QuickBooks prints were removed; every
row is one posting line. Rows are sorted by Account, then Date.

| Column | Meaning |
|---|---|
| `Date` | Transaction date, `MM/DD/YYYY` |
| `Transaction Type` | `Paycheck`, `Expense` (card), `Check`, `Bill`, `Credit Card Credit`, `Journal Entry` |
| `Num` | Check number, vendor bill/invoice number, paycheck number (`DD…`), JE number, or card reference. Often blank for card expenses. |
| `Name` | Vendor, or employee for paychecks and mileage checks; blank on journal entries |
| `Memo/Description` | Line memo as typed by staff — often terse or empty |
| `Account` | Expense account (number + name) |
| `Class` | Funding source and budget line, `GRANT-ID:LINE` (e.g. `YR-27-0093:Y3`), or `General` for unrestricted |
| `Location` | Department / program |
| `Split` | The other side of the posting: payment account for single-line transactions, `-Split-` when one transaction is spread over several lines (e.g. one receipt split across grants and General), the AP account for Bills, the offset account for journal entries |
| `Amount` | Signed amount of this posting line, 2 decimals, no currency symbol or thousands separator. **Sign convention:** as QuickBooks shows it for expense accounts — debits (costs) are **positive**, credits such as refunds/returns (`Credit Card Credit`) are **negative**. |

One vendor receipt can correspond to several GL rows (same Date, Name, Transaction Type and Num, `Split = -Split-`);
the receipt total equals the sum of those rows. Payroll rows are one per employee per class per pay date.
Fringe and indirect are monthly journal entries dated the last day of the month.

## Other files

- `receipts/` — vendor receipts and invoices for non-payroll charges (PDF; a few are PNG phone photos).
  Filenames are `YYYY-MM-DD_vendor-slug_NNNN.ext` where NNNN is the receipt/invoice number printed on the
  document (not a GL row id). Receipt dates are purchase dates; vendor names on receipts may differ slightly from
  the GL `Name` (e.g. "Costco Wholesale" vs "Costco").
- `bank_statement.csv` — `Posting Date,Description,Amount,Memo`. Bank-style uppercase descriptors with no purpose
  information. Debits **negative**, credits positive. Payroll appears as one ACH line per pay date at total gross
  (a simplification). Bills appear when paid by check.
- `staff_allocation.csv` — `employee,role,biweekly_gross_usd,allocation`; allocation is
  `GRANT:LINE=%;…;UNRESTRICTED=%` and is the approved share of each paycheck per funding line.
- `precedents.json` — prior rulings from funders/approvers: `date, by, ruling, scope`.

## Regenerate

```bash
uv run --with reportlab --with faker python scripts/generate_v2.py
```

Deterministic (fixed seeds, reportlab invariant mode). 
